/*
    This javaScript code:sets the quota identifier as combination of client id, customer_id and account id and pageNumber(in case of transactions)
*/
var identifier;

if (context.getVariable("domesticPaymentId")) {
    identifier = context.getVariable("client_id") + context.getVariable("domesticPaymentId");
}
else if(context.getVariable("consentId")) {
    identifier = context.getVariable("client_id") + context.getVariable("consentId");
}
else if(context.getVariable("domesticStandingOrderId")) {
    identifier = context.getVariable("client_id") + context.getVariable("domesticStandingOrderId");
}

context.setVariable("quotaIdentifier", identifier);