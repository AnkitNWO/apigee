var ERRORCODE= "";
var ERRORDESCRIPTION="";
var ERROR_PATH="";
var ERROR_URL=context.getVariable("ERROR_URL");
var iserror="false";

if(context.getVariable("request.verb")==="GET")
{
    if(context.getVariable("domesticPaymentId")==="")
    {
        //ERRORDESCRIPTION="DomesticPaymentID in URL "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");
        ERRORDESCRIPTION="IntentID in URL "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");
        iserror="true";
    }
    else if(context.getVariable("consentId")==="")
    {
        //ERRORDESCRIPTION="ConsentID in URL "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");
        ERRORDESCRIPTION="IntentID in URL "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");
        iserror="true";
    }
    else if(context.getVariable("domesticStandingOrderId")==="")
    {
        //ERRORDESCRIPTION="DomesticStandingOrderID in URL "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");
        ERRORDESCRIPTION="IntentID in URL "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");
        iserror="true";
    }
    
    context.setVariable("iserror", iserror);
    
    if(iserror==="true")
    {
        if((context.getVariable("isHeaderError")===true))
        {
            ERRORCODE=context.getVariable("FIELD_MISSING_ERROR_CODE");
            
            var arrA=context.getVariable("ErrorsDisplay");
            var arrB=JSON.stringify(getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL));
            
            var errorobj1 = JSON.parse(arrA);
            var errorobj2 = JSON.parse(arrB);
            
            Object.keys(errorobj2).forEach(function(key)
            {
            errorobj1.push(errorobj2[key]);
            });
            
            //context.setVariable("ErrorsDisplay1", JSON.stringify(errorobj1));
            context.setVariable("ErrorsDisplay", JSON.stringify(errorobj1));    
        }
        else
        {
            
            ERRORCODE=context.getVariable("FIELD_MISSING_ERROR_CODE");
            getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
                    
            context.setVariable("isError1", true);
            context.setVariable("Errors", Errors);
            context.setVariable("ErrorsDisplay", JSON.stringify(Errors));    
        }
    }
    else
    {
        context.setVariable("isError1", false);  
    }
}
else
{
    var paymentContextCode=context.getVariable("paymentContextCode");
    var merchantCategoryCode=context.getVariable("merchantCategoryCode");
    var merchantCustomerIdentification=context.getVariable("merchantCustomerIdentification");
    var townName=context.getVariable("townName");
    var country=context.getVariable("country");
    ERRORCODE=context.getVariable("FIELD_MISSING_ERROR_CODE");
    var RiskErrors=[];
    if(paymentContextCode==="EcommerceGoods")
    {
       if (merchantCategoryCode===null)
        {
            iserror="true";
            ERRORDESCRIPTION="MerchantCategoryCode "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");    
            
            RiskErrors=getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            
            context.setVariable("RiskErrors", JSON.stringify(Errors)); 
        }
        if(merchantCustomerIdentification==="" || merchantCustomerIdentification===null)
        {
            ERRORDESCRIPTION="MerchantCustomerIdentification "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");    
            
            RiskErrors=getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            iserror="true";
            //context.setVariable("Errors", Errors);
            context.setVariable("RiskErrors", JSON.stringify(Errors)); 
            
        }
        if(townName==="" || townName===null)
        {
            ERRORDESCRIPTION="TownName "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");    
            
            RiskErrors=getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            iserror="true";
            //context.setVariable("Errors", Errors);
            context.setVariable("RiskErrors", JSON.stringify(Errors)); 
            
        }
        if(country==="" || country===null)
        {
            ERRORDESCRIPTION="Country "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");    
           
            RiskErrors=getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            iserror="true";
            //context.setVariable("Errors", Errors);
            context.setVariable("RiskErrors", JSON.stringify(Errors)); 
            
        }
        
        if(iserror==="true")
        {
            if((context.getVariable("isHeaderError")===true) || (context.getVariable("isXSDError")===true))
            {
                var arrA=context.getVariable("ErrorsDisplay");
                var arrB=JSON.stringify(RiskErrors);
                
                var errorobj1 = JSON.parse(arrA);
                var errorobj2 = JSON.parse(arrB);
                
                Object.keys(errorobj2).forEach(function(key)
                {
                errorobj1.push(errorobj2[key]);
                });
                
                context.setVariable("ErrorsDisplay", JSON.stringify(errorobj1));    
            }
            else
            {
                //getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            
                context.setVariable("Errors", Errors);
                context.setVariable("ErrorsDisplay", JSON.stringify(Errors));     
            }
        }
    }
    else if(paymentContextCode==="EcommerceServices")
    {
        if (merchantCategoryCode===null)
        {
            iserror="true";
            ERRORDESCRIPTION="MerchantCategoryCode "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");    
            
            RiskErrors=getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            
            context.setVariable("RiskErrors", JSON.stringify(Errors)); 
        }
        if(merchantCustomerIdentification==="" || merchantCustomerIdentification===null)
        {
            ERRORDESCRIPTION="MerchantCustomerIdentification "+context.getVariable("HEADER_MISSING_ERROR_DESCRIPTION");    
            
            RiskErrors=getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            iserror="true";
            //context.setVariable("Errors", Errors);
            context.setVariable("RiskErrors", JSON.stringify(Errors)); 
            
        }
        
        if(iserror==="true")
        {
            if((context.getVariable("isHeaderError")===true) || (context.getVariable("isXSDError")===true))
            {
                var arrA=context.getVariable("ErrorsDisplay");
                var arrB=JSON.stringify(RiskErrors);
                
                var errorobj1 = JSON.parse(arrA);
                var errorobj2 = JSON.parse(arrB);
                
                Object.keys(errorobj2).forEach(function(key)
                {
                errorobj1.push(errorobj2[key]);
                });
                
                context.setVariable("ErrorsDisplay", JSON.stringify(errorobj1));    
            }
            else
            {
                //getErrors_Payload(ERRORCODE,ERRORDESCRIPTION,ERROR_URL);
            
                context.setVariable("Errors", Errors);
                context.setVariable("ErrorsDisplay", JSON.stringify(Errors));     
            }
        }
    }
}
