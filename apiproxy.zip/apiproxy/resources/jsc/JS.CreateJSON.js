 var data = "";
var data = JSON.parse(context.getVariable("response.content"));
data = JSON.stringify(data); 
context.setVariable("response.content", data);